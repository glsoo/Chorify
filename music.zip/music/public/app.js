/* Chorify UI – app.js with FontAwesome icons
   + Upload modal (no HTML changes required)
   + Admin menu (summary/users/songs) with actions
   + Animated fluid background (Vanta.js WAVES)
*/

const $ = (s) => document.querySelector(s);
const $$ = (s) => Array.from(document.querySelectorAll(s));

let ME = null;
let SONGS = [];
let PLAYLISTS = [];
let DURATIONS = new Map();

let QUEUE = [];
let QUEUE_IDX = -1;
let SHUFFLE = false;
let REPEAT = false;

let _vanta = null;
function initFluidBackground(){
  if (_vanta) _vanta.destroy();
  _vanta = VANTA.FOG({
    el: "#bg",
    THREE: window.THREE,
    // inky near-black purple palette
    baseColor: 0x030006,      // canvas base (near black)
    lowlightColor: 0x0a0016,  // deep purple shadows
    midtoneColor: 0x120020,   // wave mid
    highlightColor: 0x2a005f, // subtle purple gleam
    blurFactor: 0.2,         // more blur = smoother, “liquid” look
    speed: 0.5,               // motion speed
    zoom: 2
  });
}

window.addEventListener("resize", () => {
  if (_vanta && _vanta.resize) _vanta.resize();
});

// ------- HTTP -------
const j = async (url, opts = {}) => {
  const res = await fetch(url, {
    headers: { "Content-Type": "application/json" },
    credentials: "same-origin",
    ...opts,
  });
  if (!res.ok) throw new Error((await res.json()).error || res.statusText);
  return res.json();
};

// ------- Auth -------
async function refreshMe() {
  try {
    const data = await j("/api/auth/me");
    ME = data.user;
  } catch {
    ME = null;
  }
  renderAuth();
  renderSidebarUser();
  ensureUploadFab();      // show/hide upload button based on auth
  ensureAdminControls();  // show/hide admin controls based on role
}

function renderAuth() {
  const wrap = $("#authControls");
  if (!wrap) return;
  wrap.innerHTML = "";
  if (!ME) {
    wrap.innerHTML = `
      <button id="loginBtn" class="btn btn-ghost"><i class="fa-solid fa-right-to-bracket"></i> Login</button>
      <button id="signupBtn" class="btn btn-ghost"><i class="fa-solid fa-user-plus"></i> Register</button>
    `;
    $("#loginBtn").onclick = async () => {
      const username = prompt("Username");
      const password = prompt("Password");
      if (!username || !password) return;
      try {
        await j("/api/auth/login", { method: "POST", body: JSON.stringify({ username, password }) });
        await init();
      } catch (e) { alert(e.message); }
    };
    $("#signupBtn").onclick = async () => {
      const username = prompt("Choose a username");
      const password = prompt("Choose a password");
      if (!username || !password) return;
      try {
        await j("/api/auth/signup", { method: "POST", body: JSON.stringify({ username, password }) });
        await init();
      } catch (e) { alert(e.message); }
    };
  } else {
    wrap.innerHTML = `
      <span class="pill">${ME.isAdmin ? "Admin" : "User"}</span>
      <button id="logoutBtn" class="btn btn-ghost"><i class="fa-solid fa-right-from-bracket"></i> Logout @${ME.username}</button>
    `;
    $("#logoutBtn").onclick = async () => {
      await j("/api/auth/logout", { method: "POST" });
      await init();
    };
  }
}

function renderSidebarUser() {
  const el = $("#sidebarUser");
  if (!el) return;
  if (!ME) {
    el.innerHTML = `<div class="text-sm text-white/70">You’re browsing as guest.</div>`;
  } else {
    el.innerHTML = `
      <div class="flex items-center gap-3">
        <div class="w-9 h-9 rounded-xl glass grid place-content-center"><i class="fa-solid fa-user"></i></div>
        <div class="min-w-0">
          <div class="font-semibold truncate">@${ME.username}</div>
          <div class="text-xs text-white/60 truncate">${ME.isAdmin ? "Administrator" : "Member"}</div>
        </div>
      </div>`;
  }
}

// ------- Songs / Durations -------
async function refreshSongs() {
  const data = await j("/api/songs");
  SONGS = data.songs || [];
  await hydrateDurations(SONGS);
  renderTracks(SONGS);
  renderSidebarPlaylistsPreview();
}

function msToStr(sec) {
  const s = Math.round(sec || 0);
  const m = Math.floor(s / 60);
  const ss = String(s % 60).padStart(2, "0");
  return `${m}:${ss}`;
}

async function hydrateDurations(songs) {
  await Promise.all(
    songs.slice(0, 20).map(
      (s) =>
        new Promise((resolve) => {
          if (DURATIONS.has(s.id)) return resolve();
          const a = new Audio();
          a.src = s.url;
          a.addEventListener("loadedmetadata", () => {
            DURATIONS.set(s.id, msToStr(a.duration));
            const row = document.querySelector(`[data-row="${s.id}"] .js-duration`);
            if (row) row.textContent = DURATIONS.get(s.id);
            resolve();
          }, { once: true });
          a.addEventListener("error", () => resolve(), { once: true });
        })
    )
  );
}

// ------- Playlists -------
async function refreshPlaylists() {
  if (!ME) {
    PLAYLISTS = [];
    renderSidebarPlaylists();
    return;
  }
  const data = await j("/api/playlists");
  PLAYLISTS = data.playlists || [];
  renderSidebarPlaylists();
}

function renderSidebarPlaylists() {
  const list = $("#sidebarPlaylists");
  if (!list) return;
  list.innerHTML =
    PLAYLISTS.map(
      (p) => `
    <button class="glass-soft w-full text-left px-3 py-2 rounded-2xl hover:opacity-90 transition" data-pl="${p.id}">
      <div class="truncate font-semibold"><i class="fa-solid fa-list"></i> ${p.name}</div>
      <div class="text-xs text-white/60">${(p.songIds || []).length} songs${p.isCollaborative ? " • collab" : ""}</div>
    </button>
  `
    ).join("") || `<div class="text-sm text-white/60">No playlists yet.</div>`;
  $$("#sidebarPlaylists [data-pl]").forEach((b) => (b.onclick = () => {
    const pl = PLAYLISTS.find((x) => x.id === b.dataset.pl);
    if (!pl) return;
    const subset = SONGS.filter((s) => (pl.songIds || []).includes(s.id));
    renderTracks(subset, pl.name);
  }));
}

function renderSidebarPlaylistsPreview() {}

$("#newPlaylist")?.addEventListener("click", async () => {
  if (!ME) return alert("Log in first");
  const name = prompt("Playlist name?");
  if (!name) return;
  try {
    await j("/api/playlists", { method: "POST", body: JSON.stringify({ name }) });
    await refreshPlaylists();
  } catch (e) { alert(e.message); }
});

// ------- Topbar search -------
$("#search")?.addEventListener("input", () => {
  const q = ($("#search").value || "").toLowerCase();
  const filtered = SONGS.filter((s) =>
    [s.title, s.artist, s.genre, (s.tags || []).join(" ")].join(" ").toLowerCase().includes(q)
  );
  renderTracks(filtered);
});

// ------- Track list render -------
function renderTracks(items, title) {
  const list = $("#trackList");
  if (!list) return;
  list.innerHTML = title
    ? `<div class="px-3 py-2 text-sm text-white/60">Showing: <span class="pill">${title}</span></div>`
    : "";
  const rows = items.map((s, i) => trackRowHTML(s, i + 1)).join("");
  list.innerHTML += rows;
  hookTrackRowEvents();
}

function trackRowHTML(s, index) {
  const n = String(index).padStart(2, "0");
  const dur = DURATIONS.get(s.id) || "• • •";
  return `
  <div class="card-row" data-row="${s.id}">
    <div class="w-11 h-11 rounded-full glass-soft grid place-content-center font-extrabold">${n}</div>
    <img class="cover" src="${s.coverUrl || "https://dummyimage.com/64x64/0b1020/ffffff&text=%E2%99%AA"}" alt="">
    <div class="flex-1 min-w-0">
      <div class="font-semibold truncate">${s.title}</div>
      <div class="text-sm text-white/70 truncate">${s.artist}${s.genre ? " • " + s.genre : ""}</div>
    </div>
    <div class="meta w-32 justify-end">
      <span class="js-duration">${dur}</span>
    </div>
    <div class="flex items-center gap-2 pl-2">
      <button class="icon-btn btn-primary js-play" title="Play" data-id="${s.id}">
        <i class="fa-solid fa-play"></i>
      </button>
      <button class="icon-btn btn-ghost js-add" title="Add to playlist" data-id="${s.id}">
        <i class="fa-solid fa-plus"></i>
      </button>
    </div>
  </div>`;
}

function hookTrackRowEvents() {
  $$(".js-play").forEach((b) => (b.onclick = () => playSongById(b.dataset.id)));
  $$(".js-add").forEach((b) => (b.onclick = () => addToPlaylistPrompt(b.dataset.id)));
}

function addToPlaylistPrompt(songId) {
  if (!ME) return alert("Log in first");
  if (!PLAYLISTS.length) return alert("Create a playlist first.");
  const names = PLAYLISTS.map((p, i) => `${i + 1}. ${p.name}`).join("\n");
  const idx = parseInt(prompt("Add to which playlist?\n" + names), 10) - 1;
  if (isNaN(idx) || idx < 0 || idx >= PLAYLISTS.length) return;
  const p = PLAYLISTS[idx];
  j(`/api/playlists/${p.id}/add`, { method: "POST", body: JSON.stringify({ songId }) })
    .then(() => alert(`Added to ${p.name}`))
    .catch((e) => alert(e.message));
}

// ------- Player -------
const player = $("#player");
const npTitle = $("#npTitle");
const npArtist = $("#npArtist");
const npCover = $("#npCover");
const seek = $("#seek");
const vol = $("#volume");

$("#shuffle")?.addEventListener("click", () => {
  SHUFFLE = !SHUFFLE;
  $("#shuffle i").className = SHUFFLE ? "fa-solid fa-shuffle text-purple-400" : "fa-solid fa-shuffle";
});
$("#repeat")?.addEventListener("click", () => {
  REPEAT = !REPEAT;
  $("#repeat i").className = REPEAT ? "fa-solid fa-repeat text-purple-400" : "fa-solid fa-repeat";
});
$("#play")?.addEventListener("click", () => {
  if (player.paused) player.play(); else player.pause();
});
$("#prev")?.addEventListener("click", () => {
  if (QUEUE_IDX > 0) { QUEUE_IDX--; loadCurrent(); }
});
$("#next")?.addEventListener("click", () => nextInQueue());

vol?.addEventListener("input", () => (player.volume = parseFloat(vol.value)));
player && (player.ontimeupdate = () => {
  if (player.duration) seek.value = Math.floor((player.currentTime / player.duration) * 100);
});
seek && (seek.oninput = () => {
  if (player.duration) player.currentTime = player.duration * (parseInt(seek.value, 10) / 100);
});
player && (player.onplay = () => ($("#play i").className = "fa-solid fa-pause"));
player && (player.onpause = () => ($("#play i").className = "fa-solid fa-play"));
player && (player.onended = () => { if (REPEAT) { player.currentTime = 0; player.play(); } else nextInQueue(); });

$("#likeNow")?.addEventListener("click", () => {
  if (!ME) return alert("Log in first");
  const s = QUEUE[QUEUE_IDX]; if (!s) return;
  const icon = $("#likeNow i");
  const liked = icon.classList.contains("fa-solid");
  icon.className = liked ? "fa-regular fa-heart" : "fa-solid fa-heart text-purple-400";
  j(`/api/songs/like/${s.id}`, { method: "POST" })
    .then(() => refreshSongs())
    .catch((e) => alert(e.message));
});

function playSongById(id) {
  const idx = SONGS.findIndex((s) => s.id === id);
  if (idx === -1) return;
  QUEUE = SONGS.slice(idx).concat(SONGS.slice(0, idx));
  if (SHUFFLE) QUEUE.sort(() => Math.random() - 0.5);
  QUEUE_IDX = 0;
  loadCurrent();
}

function loadCurrent() {
  if (QUEUE_IDX < 0 || QUEUE_IDX >= QUEUE.length) return;
  const s = QUEUE[QUEUE_IDX];
  if (player) {
    player.src = s.url;
    npTitle && (npTitle.textContent = s.title);
    npArtist && (npArtist.textContent = s.artist);
    npCover && (npCover.src = s.coverUrl || "https://dummyimage.com/64x64/0b1020/ffffff&text=%E2%99%AA");
    player.play();
  }
  if (ME) j(`/api/songs/played/${s.id}`, { method: "POST" }).catch(() => {});
}

function nextInQueue() {
  if (QUEUE_IDX < QUEUE.length - 1) { QUEUE_IDX++; loadCurrent(); }
}

// ------- Theme toggle (swap wave color live) -------
$("#themeBtn")?.addEventListener("click", () => {
  // Just a subtle effect: nudge the primary wave color when clicked
  if (_vanta && _vanta.setOptions) {
    const colors = [0x9b5cff, 0x6a28ff, 0xc083ff];
    const current = _vanta.options.color;
    const idx = (colors.indexOf(current) + 1) % colors.length;
    _vanta.setOptions({ color: colors[idx] });
  } else {
    alert("Purple mode engaged ✨");
  }
});

/* =========================================================================
   UPLOAD: floating action button + modal (no HTML changes needed)
   ========================================================================= */
function ensureUploadFab() {
  let fab = $("#uploadFab");
  if (!ME) { if (fab) fab.remove(); return; } // hide for guests
  if (fab) return;
  fab = document.createElement("button");
  fab.id = "uploadFab";
  fab.className = "fixed bottom-28 right-6 md:right-8 z-50 btn btn-primary icon-btn";
  fab.innerHTML = `<i class="fa-solid fa-cloud-arrow-up"></i>`;
  document.body.appendChild(fab);
  fab.onclick = openUploadModal;
}

function openUploadModal() {
  const modal = document.createElement("div");
  modal.id = "uploadModal";
  modal.className = "fixed inset-0 z-50 flex items-center justify-center p-4";
  modal.innerHTML = `
    <div class="absolute inset-0 bg-black/60"></div>
    <div class="glass rounded-3xl p-4 w-full max-w-md relative">
      <button class="absolute top-2 right-2 icon-btn btn-ghost" id="closeUpload"><i class="fa-solid fa-xmark"></i></button>
      <div class="text-lg font-bold mb-2"><i class="fa-solid fa-cloud-arrow-up"></i> Upload audio</div>
      <form id="uploadForm" class="grid gap-2">
        <input class="input" name="title" placeholder="Title" required />
        <input class="input" name="artist" placeholder="Artist" required />
        <input class="input" name="genre" placeholder="Genre (optional)" />
        <input class="input" name="tags" placeholder="Tags (comma separated)" />
        <label class="text-sm">Audio file<input class="input mt-1" type="file" name="audio" accept="audio/*" required /></label>
        <label class="text-sm">Cover image (optional)<input class="input mt-1" type="file" name="cover" accept="image/*" /></label>
        <button class="btn btn-primary mt-1"><i class="fa-solid fa-arrow-up-from-bracket"></i> Upload</button>
        <p class="text-xs text-white/70">Allowed: mp3, wav, ogg, m4a, flac…</p>
      </form>
    </div>`;
  document.body.appendChild(modal);

  $("#closeUpload").onclick = () => modal.remove();

  $("#uploadForm").onsubmit = async (e) => {
    e.preventDefault();
    if (!ME) return alert("Log in first");
    const fd = new FormData(e.target);
    const audio = fd.get("audio");
    if (!audio || !audio.size) return alert("Please select an audio file.");
    try {
      const res = await fetch("/api/songs/upload", { method: "POST", body: fd, credentials: "same-origin" });
      if (!res.ok) throw new Error((await res.json()).error || "Upload failed");
      const { song } = await res.json();
      // optional cover upload if provided
      const cover = fd.get("cover");
      if (cover && cover.size) {
        const fd2 = new FormData();
        fd2.append("cover", cover);
        await fetch(`/api/songs/${song.id}/cover`, { method: "POST", body: fd2, credentials: "same-origin" });
      }
      modal.remove();
      await refreshSongs();
      alert("Uploaded!");
    } catch (err) { alert(err.message); }
  };
}

/* =========================================================================
   ADMIN: button + slide-over panel (summary/users/songs with delete)
   ========================================================================= */
function ensureAdminControls() {
  // Admin button in topbar
  let btn = $("#adminBtn");
  if (!ME || !ME.isAdmin) {
    if (btn) btn.remove();
    const panel = $("#adminPanel"); if (panel) panel.remove();
    return;
  }
  if (!btn) {
    btn = document.createElement("button");
    btn.id = "adminBtn";
    btn.className = "pill";
    btn.innerHTML = `<i class="fa-solid fa-screwdriver-wrench"></i> Admin`;
    $("#authControls")?.prepend(btn);
    btn.onclick = toggleAdminPanel;
  }
}

function toggleAdminPanel() {
  let panel = $("#adminPanel");
  if (panel) { panel.remove(); return; }
  panel = document.createElement("div");
  panel.id = "adminPanel";
  panel.className = "fixed top-4 right-4 z-50 w-[min(92vw,760px)]";
  panel.innerHTML = `
    <div class="glass rounded-3xl p-4">
      <div class="flex items-center justify-between">
        <div class="font-bold text-lg"><i class="fa-solid fa-gauge-high"></i> Admin Panel</div>
        <div class="flex items-center gap-2">
          <button id="adminRefresh" class="btn btn-ghost"><i class="fa-solid fa-rotate"></i> Refresh</button>
          <button id="adminClose" class="icon-btn btn-ghost"><i class="fa-solid fa-xmark"></i></button>
        </div>
      </div>
      <div id="adminSummary" class="mt-3 text-sm"></div>
      <div class="mt-3 flex gap-2 flex-wrap">
        <button id="adminTabSongs" class="btn btn-ghost"><i class="fa-solid fa-music"></i> Songs</button>
        <button id="adminTabUsers" class="btn btn-ghost"><i class="fa-solid fa-users"></i> Users</button>
      </div>
      <div id="adminDetails" class="mt-3"></div>
    </div>`;
  document.body.appendChild(panel);

  $("#adminClose").onclick = () => panel.remove();
  $("#adminRefresh").onclick = refreshAdminSummary;
  $("#adminTabSongs").onclick = openAdminSongs;
  $("#adminTabUsers").onclick = openAdminUsers;

  refreshAdminSummary();
}

async function refreshAdminSummary() {
  try {
    const s = await j("/api/admin/summary");
    $("#adminSummary").innerHTML = `
      <div class="grid grid-cols-2 md:grid-cols-4 gap-2">
        <div class="glass-soft rounded-xl p-2">Users <div class="text-2xl font-extrabold">${s.users}</div></div>
        <div class="glass-soft rounded-xl p-2">Songs <div class="text-2xl font-extrabold">${s.songs}</div></div>
        <div class="glass-soft rounded-xl p-2">Feedback <div class="text-2xl font-extrabold">${s.feedback}</div></div>
        <div class="glass-soft rounded-xl p-2">Storage <div class="text-2xl font-extrabold">${(s.uploadsBytes/1024/1024).toFixed(1)} MB</div></div>
      </div>`;
  } catch (e) {
    $("#adminSummary").textContent = "Summary unavailable: " + e.message;
  }
}

async function openAdminSongs() {
  try {
    const data = await j("/api/admin/songs");
    $("#adminDetails").innerHTML =
      data.songs.map(s => `
        <div class="glass-soft rounded-xl p-2 flex items-center justify-between gap-3">
          <div class="flex items-center gap-3 min-w-0">
            <img src="${s.coverUrl || "https://dummyimage.com/48x48/0b1020/ffffff&text=%E2%99%AA"}" class="w-12 h-12 rounded-xl object-cover"/>
            <div class="min-w-0">
              <div class="font-semibold truncate">${s.title}</div>
              <div class="text-xs text-white/60 truncate">${s.artist} • likes: ${s.likes || 0}</div>
            </div>
          </div>
          <div class="flex items-center gap-2">
            <audio controls src="${s.url}" style="width:220px"></audio>
            <button class="btn btn-ghost js-del-song" data-id="${s.id}">
              <i class="fa-solid fa-trash-can"></i> Delete
            </button>
          </div>
        </div>`).join("") || `<div class="text-white/70">No songs yet</div>`;
    $$(".js-del-song").forEach(b => b.onclick = async () => {
      if (!confirm("Delete this song?")) return;
      try {
        await j(`/api/admin/songs/${b.dataset.id}/delete`, { method: "POST" });
        await openAdminSongs();
        await refreshSongs();
      } catch (e) { alert(e.message); }
    });
  } catch (e) { alert(e.message); }
}

async function openAdminUsers() {
  try {
    const data = await j("/api/admin/users");
    $("#adminDetails").innerHTML =
      data.users.map(u => `
        <div class="glass-soft rounded-xl p-2 flex items-center justify-between">
          <div>
            <div class="font-semibold">@${u.username}</div>
            <div class="text-xs text-white/60">Role: ${u.isAdmin ? "Admin" : "User"} • Joined: ${new Date(u.createdAt).toLocaleString()}</div>
          </div>
        </div>`).join("");
  } catch (e) { alert(e.message); }
}

// ------- Boot -------
async function init() {
  await refreshMe();
  await refreshSongs();
  await refreshPlaylists();
}
document.addEventListener("DOMContentLoaded", () => {
  initFluidBackground(); // start animated background
  init();                // boot the app
});
