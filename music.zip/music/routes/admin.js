
const express = require("express");
const path = require("path");
const fs = require("fs");
const { getUsers, getSongs, setSongs, getFeedback, getSettings, setSettings, getPlaylists, setPlaylists, UPLOADS_DIR, COVERS_DIR } = require("../lib/datastore");
const router = express.Router();

function adminRequired(req,res,next){
  const u = getUsers().find(u=>u.id===req.session.userId);
  if (!u || !u.isAdmin) return res.status(403).json({ error:"Admin only" });
  next();
}

router.get("/summary", adminRequired, (req,res)=>{
  const users = getUsers();
  const songs = getSongs();
  const feedback = getFeedback();
  const uploadsBytes = songs.reduce((sum,s)=> sum + (fs.existsSync(path.join(UPLOADS_DIR, s.filename)) ? fs.statSync(path.join(UPLOADS_DIR, s.filename)).size : 0), 0);
  res.json({ users: users.length, songs: songs.length, feedback: feedback.length, uploadsBytes, settings: getSettings() });
});

router.get("/users", adminRequired, (req,res)=> res.json({ users: getUsers().map(u=>({ id:u.id, username:u.username, isAdmin:!!u.isAdmin, createdAt:u.createdAt })) }));

router.get("/songs", adminRequired, (req,res)=>{
  const songs = getSongs().map(s=>({ ...s, url:`/uploads/${s.filename}`, coverUrl: s.coverFilename? `/uploads/covers/${s.coverFilename}`: null }));
  res.json({ songs });
});

router.post("/songs/:id/delete", adminRequired, (req,res)=>{
  const songs = getSongs();
  const idx = songs.findIndex(s=>s.id===req.params.id);
  if (idx===-1) return res.status(404).json({ error:"Song not found" });
  const [removed] = songs.splice(idx,1);
  try { fs.unlinkSync(path.join(UPLOADS_DIR, removed.filename)); } catch {}
  if (removed.coverFilename) { try { fs.unlinkSync(path.join(COVERS_DIR, removed.coverFilename)); } catch {} }
  setSongs(songs);
  const pls = getPlaylists();
  pls.forEach(p => p.songIds = (p.songIds||[]).filter(id => id !== removed.id));
  setPlaylists(pls);
  res.json({ ok:true });
});

router.post("/settings", adminRequired, (req,res)=>{
  const s = { ...getSettings(), ...req.body };
  s.ads = false; // keep off by requirement
  setSettings(s);
  res.json({ settings: s });
});

module.exports = router;
