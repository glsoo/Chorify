
const express = require("express");
const path = require("path");
const fs = require("fs");
const multer = require("multer");
const mime = require("mime-types");
const { getUsers, setUsers, getSongs, setSongs, getPlaylists, setPlaylists, UPLOADS_DIR, COVERS_DIR, uuid } = require("../lib/datastore");

const router = express.Router();

const uploadAudio = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => cb(null, UPLOADS_DIR),
    filename: (req, file, cb) => {
      const ext = mime.extension(file.mimetype) || path.extname(file.originalname) || "bin";
      cb(null, `${Date.now()}-${uuid()}.${ext}`);
    }
  }),
  fileFilter: (req, file, cb) => {
    const ok = ["audio/mpeg","audio/mp3","audio/wav","audio/x-wav","audio/ogg","audio/webm","audio/aac","audio/flac","audio/x-flac","audio/m4a"].includes(file.mimetype);
    if (!ok) return cb(new Error("Only audio files."));
    cb(null, true);
  },
  limits: { fileSize: 1024*1024*100 }
});
const uploadCover = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => cb(null, COVERS_DIR),
    filename: (req, file, cb) => {
      const ext = mime.extension(file.mimetype) || path.extname(file.originalname) || "jpg";
      cb(null, `${Date.now()}-${uuid()}.${ext}`);
    }
  }),
  fileFilter: (req, file, cb) => {
    if (!String(file.mimetype).startsWith("image/")) return cb(new Error("Only images."));
    cb(null, true);
  },
  limits: { fileSize: 1024*1024*10 }
});

function authRequired(req,res,next){ if(!req.session.userId) return res.status(401).json({error:"Not authenticated"}); next(); }
function me(req){ return getUsers().find(u=>u.id===req.session.userId) || null; }
const publicSong = (s, meUser) => ({ ...s, url: `/uploads/${s.filename}`, coverUrl: s.coverFilename? `/uploads/covers/${s.coverFilename}`: null, liked: !!(meUser && (meUser.likes||[]).includes(s.id)), canEdit: !!(meUser && (meUser.isAdmin || s.uploaderId===meUser.id)) });

router.get("/", (req,res)=>{
  const u = me(req);
  res.json({ songs: getSongs().map(s => publicSong(s, u)) });
});

router.get("/mine", authRequired, (req,res)=>{
  const songs = getSongs().filter(s=>s.uploaderId===req.session.userId).map(s=> publicSong(s, me(req)));
  res.json({ songs });
});

router.post("/upload", authRequired, uploadAudio.single("audio"), (req,res)=>{
  const { title="Untitled", artist="Unknown", genre="", tags="" } = req.body;
  if (!req.file) return res.status(400).json({ error:"No audio" });
  const songs = getSongs();
  const song = {
    id: uuid(),
    title, artist, genre,
    tags: String(tags||"").split(",").map(s=>s.trim()).filter(Boolean),
    filename: path.basename(req.file.path),
    mimetype: req.file.mimetype,
    uploaderId: req.session.userId,
    uploadedAt: new Date().toISOString(),
    likes: 0, likedBy: []
  };
  songs.push(song); setSongs(songs);
  res.json({ song: publicSong(song, me(req)) });
});

router.post("/:id/edit", authRequired, (req,res)=>{
  const songs = getSongs();
  const users = getUsers();
  const m = users.find(u=>u.id===req.session.userId);
  const idx = songs.findIndex(s=>s.id===req.params.id);
  if (idx===-1) return res.status(404).json({ error:"Song not found" });
  const s = songs[idx];
  if (!(m.isAdmin || s.uploaderId===m.id)) return res.status(403).json({ error:"Not allowed" });
  const { title, artist, genre, tags } = req.body;
  if (title!==undefined) s.title = String(title).slice(0,200);
  if (artist!==undefined) s.artist = String(artist).slice(0,200);
  if (genre!==undefined) s.genre = String(genre).slice(0,100);
  if (tags!==undefined) s.tags = String(tags).split(",").map(t=>t.trim()).filter(Boolean);
  setSongs(songs);
  res.json({ song: publicSong(s, m) });
});

router.post("/:id/replace-audio", authRequired, uploadAudio.single("audio"), (req,res)=>{
  const songs = getSongs();
  const users = getUsers();
  const m = users.find(u=>u.id===req.session.userId);
  const idx = songs.findIndex(s=>s.id===req.params.id);
  if (idx===-1) return res.status(404).json({ error:"Song not found" });
  const s = songs[idx];
  if (!(m.isAdmin || s.uploaderId===m.id)) return res.status(403).json({ error:"Not allowed" });
  if (!req.file) return res.status(400).json({ error:"No audio" });
  try { fs.unlinkSync(path.join(UPLOADS_DIR, s.filename)); } catch {}
  s.filename = path.basename(req.file.path);
  s.mimetype = req.file.mimetype;
  setSongs(songs);
  res.json({ song: publicSong(s, m) });
});

router.post("/:id/cover", authRequired, uploadCover.single("cover"), (req,res)=>{
  const songs = getSongs();
  const users = getUsers();
  const m = users.find(u=>u.id===req.session.userId);
  const idx = songs.findIndex(s=>s.id===req.params.id);
  if (idx===-1) return res.status(404).json({ error:"Song not found" });
  const s = songs[idx];
  if (!(m.isAdmin || s.uploaderId===m.id)) return res.status(403).json({ error:"Not allowed" });
  if (!req.file) return res.status(400).json({ error:"No cover" });
  if (s.coverFilename) { try { fs.unlinkSync(path.join(COVERS_DIR, s.coverFilename)); } catch {} }
  s.coverFilename = path.basename(req.file.path);
  setSongs(songs);
  res.json({ song: publicSong(s, m) });
});

router.post("/:id/delete", authRequired, (req,res)=>{
  const songs = getSongs();
  const users = getUsers();
  const m = users.find(u=>u.id===req.session.userId);
  const idx = songs.findIndex(s=>s.id===req.params.id);
  if (idx===-1) return res.status(404).json({ error:"Song not found" });
  const s = songs[idx];
  if (!(m.isAdmin || s.uploaderId===m.id)) return res.status(403).json({ error:"Not allowed" });
  songs.splice(idx,1);
  try { fs.unlinkSync(path.join(UPLOADS_DIR, s.filename)); } catch {}
  if (s.coverFilename) { try { fs.unlinkSync(path.join(COVERS_DIR, s.coverFilename)); } catch {} }
  setSongs(songs);
  const pls = getPlaylists();
  pls.forEach(p => p.songIds = (p.songIds||[]).filter(id => id !== s.id));
  setPlaylists(pls);
  res.json({ ok:true });
});

router.post("/like/:id", authRequired, (req,res)=>{
  const users = getUsers();
  const songs = getSongs();
  const m = users.find(u=>u.id===req.session.userId);
  const s = songs.find(s=>s.id===req.params.id);
  if (!s) return res.status(404).json({ error:"Song not found" });
  m.likes = m.likes || [];
  const i = m.likes.indexOf(s.id);
  if (i>=0) { m.likes.splice(i,1); s.likes = Math.max(0,(s.likes||0)-1); s.likedBy=(s.likedBy||[]).filter(id=>id!==m.id); }
  else { m.likes.push(s.id); s.likes=(s.likes||0)+1; s.likedBy=Array.from(new Set([...(s.likedBy||[]), m.id])); }
  setUsers(users); setSongs(songs);
  res.json({ liked: i===-1, likes: s.likes });
});

router.post("/played/:id", authRequired, (req,res)=>{
  const users = getUsers();
  const m = users.find(u=>u.id===req.session.userId);
  m.recent = m.recent || [];
  m.recent.unshift({ songId: req.params.id, at: new Date().toISOString() });
  m.recent = m.recent.slice(0,50);
  setUsers(users);
  res.json({ ok:true });
});

module.exports = router;
