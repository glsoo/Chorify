
const express = require("express");
const bcrypt = require("bcrypt");
const { getUsers, setUsers, uuid } = require("../lib/datastore");
const router = express.Router();

function publicUser(u){ return { id:u.id, username:u.username, isAdmin:!!u.isAdmin, createdAt:u.createdAt }; }

router.post("/signup", async (req,res)=>{
  const { username, password } = req.body;
  if (!username || !password) return res.status(400).json({ error:"username and password required" });
  const users = getUsers();
  if (users.some(u=>u.username.toLowerCase()===String(username).toLowerCase())) return res.status(400).json({ error:"Username exists" });
  const passwordHash = await bcrypt.hash(password, 10);
  const user = { id: uuid(), username, passwordHash, isAdmin:false, createdAt: new Date().toISOString(), likes:[], follows:[], recent:[] };
  users.push(user); setUsers(users);
  req.session.userId = user.id;
  res.json({ user: publicUser(user) });
});

router.post("/login", async (req,res)=>{
  const { username, password } = req.body;
  const users = getUsers();
  const user = users.find(u=>u.username.toLowerCase()===String(username).toLowerCase());
  if (!user) return res.status(400).json({ error:"Invalid credentials" });
  const ok = await bcrypt.compare(password, user.passwordHash);
  if (!ok) return res.status(400).json({ error:"Invalid credentials" });
  req.session.userId = user.id;
  res.json({ user: publicUser(user) });
});

router.post("/logout", (req,res)=> req.session.destroy(()=>res.json({ ok:true })));

router.get("/me", (req,res)=>{
  const users = getUsers();
  const me = users.find(u=>u.id===req.session.userId);
  res.json({ user: me ? publicUser(me) : null });
});

// bootstrap default admin on first request if none
router.use((req,res,next)=>{
  const users = getUsers();
  if (!users.some(u=>u.isAdmin)) {
    (async ()=>{
      const bcrypt2 = require("bcrypt");
      const hash = await bcrypt2.hash("admin", 10);
      users.push({ id: uuid(), username:"admin", passwordHash:hash, isAdmin:true, createdAt:new Date().toISOString(), likes:[], follows:[], recent:[] });
      setUsers(users);
      next();
    })();
  } else next();
});

module.exports = router;
