
const express = require("express");
const { getSongs, getPlaylists, setPlaylists, getUsers, uuid } = require("../lib/datastore");
const router = express.Router();

function authRequired(req,res,next){ if(!req.session.userId) return res.status(401).json({error:"Not authenticated"}); next(); }

router.get("/", authRequired, (req,res)=>{
  const pls = getPlaylists().filter(p => p.userId===req.session.userId || (p.isCollaborative && (p.collaborators||[]).includes(req.session.userId)));
  res.json({ playlists: pls });
});

router.post("/", authRequired, (req,res)=>{
  const { name, isCollaborative=false } = req.body;
  if (!name) return res.status(400).json({ error:"name required" });
  const pls = getPlaylists();
  const p = { id: uuid(), userId: req.session.userId, name, songIds: [], isCollaborative: !!isCollaborative, collaborators: [], createdAt: new Date().toISOString() };
  pls.push(p); setPlaylists(pls);
  res.json({ playlist: p });
});

router.post("/:id/add", authRequired, (req,res)=>{
  const { songId } = req.body;
  const pls = getPlaylists();
  const p = pls.find(pp=>pp.id===req.params.id);
  if (!p) return res.status(404).json({ error:"Playlist not found" });
  const can = p.userId===req.session.userId || (p.isCollaborative && (p.collaborators||[]).includes(req.session.userId));
  if (!can) return res.status(403).json({ error:"Not allowed" });
  const songs = getSongs();
  if (!songs.some(s=>s.id===songId)) return res.status(404).json({ error:"Song not found" });
  p.songIds = Array.from(new Set([...(p.songIds||[]), songId]));
  setPlaylists(pls);
  res.json({ playlist: p });
});

router.post("/:id/remove", authRequired, (req,res)=>{
  const { songId } = req.body;
  const pls = getPlaylists();
  const p = pls.find(pp=>pp.id===req.params.id);
  if (!p) return res.status(404).json({ error:"Playlist not found" });
  const can = p.userId===req.session.userId || (p.isCollaborative && (p.collaborators||[]).includes(req.session.userId));
  if (!can) return res.status(403).json({ error:"Not allowed" });
  p.songIds = (p.songIds||[]).filter(id=>id!==songId);
  setPlaylists(pls);
  res.json({ playlist: p });
});

router.post("/:id/collaborators", authRequired, (req,res)=>{
  const { action, userId } = req.body;
  const pls = getPlaylists();
  const p = pls.find(pp=>pp.id===req.params.id);
  if (!p) return res.status(404).json({ error:"Playlist not found" });
  if (p.userId !== req.session.userId) return res.status(403).json({ error:"Owner only" });
  p.isCollaborative = true;
  p.collaborators = p.collaborators || [];
  if (action==="add" && userId) p.collaborators = Array.from(new Set([...p.collaborators, userId]));
  if (action==="remove" && userId) p.collaborators = p.collaborators.filter(id=>id!==userId);
  setPlaylists(pls);
  res.json({ playlist: p });
});

module.exports = router;
